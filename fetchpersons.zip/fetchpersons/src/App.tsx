import React from 'react';
import logo from './logo.svg';
import './App.css';
import PersonsList from './components/PersonsList';

function App() {
  return (
    <div className="App">
      <PersonsList/>
    </div>
  );
}

export default App;
